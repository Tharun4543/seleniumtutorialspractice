package SeleniumTraining.TestNG;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext ;		
import org.testng.ITestListener ;		
import org.testng.ITestResult ;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;


public class ListernerTest extends baseclasses implements ITestListener {
	
	WebDriver driver;
	ExtentReports extent;
	ExtentTest test;

	public void onTestStart(ITestResult result) {
		//report gets in touch with the testcase
		test = extent.createTest(result.getMethod().getMethodName());
	}

	public void onTestSuccess(ITestResult result) {
		
		String testcasename = result.getMethod().getMethodName();
		test.log(Status.PASS, "Test Case has passed");
		String path = null;
		try {
			driver = (WebDriver) result.getTestClass().getRealClass().getDeclaredField("driver").get(result.getInstance());
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			path = takesnapshot(driver, testcasename);
		} catch (IOException e) {
			e.printStackTrace();
		}
		test.addScreenCaptureFromPath(path);
		
	}

	public void onTestFailure(ITestResult result) {
		String testcasename = result.getMethod().getMethodName();
		test.log(Status.FAIL, "Test Case has failed");
		String path = null;
		try {
			driver = (WebDriver) result.getTestClass().getRealClass().getDeclaredField("driver").get(result.getInstance());
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			path = takesnapshot(driver, testcasename);
		} catch (IOException e) {
			e.printStackTrace();
		}
		test.addScreenCaptureFromPath(path);
	}

	public void onTestSkipped(ITestResult result) {
		String testcasename = result.getMethod().getMethodName();
		test.log(Status.SKIP, "Test Case has skipped");
		String path = null;
		try {
			driver = (WebDriver) result.getTestClass().getRealClass().getDeclaredField("driver").get(result.getInstance());
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			takesnapshot(driver, testcasename);
		} catch (IOException e) {
			e.printStackTrace();
		}
		test.addScreenCaptureFromPath(path);
	}	
	

	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
	
	}

	public void onTestFailedWithTimeout(ITestResult result) {
	
	}

	public void onStart(ITestContext context) {
		// reports config is called to generate
		extent = reportconfig();
	}

	public void onFinish(ITestContext context) {
		//reports are flushed and saved in the path
		extent.flush();
	}

	
	
	
}
