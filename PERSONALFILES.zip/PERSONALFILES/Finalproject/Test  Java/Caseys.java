package SeleniumTraining.TestNG;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class CaseysMain extends baseclasses {

	WebDriver driver;
	Properties prop;

	@BeforeMethod
	public void browserlaunch() throws IOException {
		prop = getdata();
		driver = initializebrowser(prop.getProperty("caseysurl"));
	}
	@Test
	public void TestCase1() throws InterruptedException, IOException {

		Caseys_HomePage chp = new Caseys_HomePage(driver);
		Caseys_AddressPage cap = new Caseys_AddressPage(driver);
		Caseys_Menu cm = new Caseys_Menu(driver);
		Caseys_PizzaPage cpp = new Caseys_PizzaPage(driver);
		Caseys_STPPage cstpp = new Caseys_STPPage(driver);
		Caseys_ReviewPage crp = new Caseys_ReviewPage(driver);
		Caseys_CheckoutPage ccop = new Caseys_CheckoutPage(driver);
		Caseys_GuestPage cgp = new Caseys_GuestPage(driver);
		Caseys_PaymentPage cpyp = new Caseys_PaymentPage(driver);

		Actions action = new Actions(driver);
		prop = getdata();

		chp.frameclose().click();
		driver.switchTo().defaultContent();
		chp.pickupbutton().click();
		chp.pickuptextbox().sendKeys(prop.getProperty("address"));
		action.pause(Duration.ofSeconds(3)).sendKeys(Keys.ENTER).build().perform();

		cap.startorderclick().click();
		driver.navigate().refresh();
	//	cm.menutextvisible();
		System.out.println("verified the text");
		cm.pizzaclick().click();
		cpp.pizzabuttonclick().click();
		cstpp.choosepizzatextwait();
		cstpp.addbuttonclick().click();
		crp.reviewbuttonclick().click();

		ccop.yourordertextwait();
		action.sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ARROW_DOWN).build().perform();
		ccop.checkoutbuttonclick().click();

		cgp.guestcheckoutbuttonclick().click();
		cgp.firstnametextbox().sendKeys(prop.getProperty("firstname"));
		cgp.lastnametextbox().sendKeys(prop.getProperty("lastname"));
		cgp.emailtextbox().sendKeys(prop.getProperty("email"));
		cgp.phonenumbertextbox().sendKeys(prop.getProperty("phone"));
		cgp.continuebuttonclick().click();

		String finaltext = cpyp.finalpizzatext().getText();
		String expectedtext = "Pepperoni Pizza";
		Assert.assertEquals(finaltext, expectedtext);
	}

	@Test
	public void TestCase2() throws InterruptedException, IOException {
		Caseys_HomePage chp = new Caseys_HomePage(driver);
		Caseys_AddressPage cap = new Caseys_AddressPage(driver);
		Caseys_Menu cm = new Caseys_Menu(driver);
		Caseys_PizzaPage cpp = new Caseys_PizzaPage(driver);
		Caseys_STPPage cstpp = new Caseys_STPPage(driver);
		Caseys_ReviewPage crp = new Caseys_ReviewPage(driver);
		Caseys_CheckoutPage ccop = new Caseys_CheckoutPage(driver);
		Caseys_GuestPage cgp = new Caseys_GuestPage(driver);
		Caseys_PaymentPage cpyp = new Caseys_PaymentPage(driver);

		Actions action = new Actions(driver);
		// prop=getdata();
		chp.frameclose().click();
		driver.switchTo().defaultContent();
		chp.deliverybuttonclick().click();
		chp.pickuptextbox().sendKeys(prop.getProperty("address"));
		action.pause(Duration.ofSeconds(3)).sendKeys(Keys.ENTER).build().perform();

		cap.timebuttonclick().click();
		cap.timeselectoption().click();
		cap.delstartorderbuttonclick().click();
		cm.menutextvisible();
		cm.pizzaclick().click();
		cpp.pizzabuttonclick().click();
		cstpp.choosepizzatextwait();
		cstpp.quantityclick().click();
		cstpp.pizzacountclick().click();
		cstpp.addbuttonclick().click();
		crp.reviewbuttonclick().click();

		ccop.yourordertextwait();
		action.sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ARROW_DOWN)
				.sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ARROW_DOWN).build().perform();
		ccop.checkoutbuttonclick().click();

		cgp.guestcheckoutbuttonclick().click();
		cgp.firstnametextbox().sendKeys(prop.getProperty("firstname"));
		cgp.lastnametextbox().sendKeys(prop.getProperty("lastname"));
		cgp.emailtextbox().sendKeys(prop.getProperty("email"));
		cgp.phonenumbertextbox().sendKeys(prop.getProperty("phone"));
		cgp.continuebuttonclick().click();

		String finaltext = cpyp.finalpizzatext().getText();
		String finalcnt = cpyp.finalpizzacntext().getText();
		String amt = driver.findElement(By.xpath("//div[@class='row']/div[@class='col-4 text-right v-cloak']"))
				.getText();
		System.out.println(amt);
		String expectedtext = "Pepperoni Pizza";
		Assert.assertEquals(finalcnt+finaltext, expectedtext);
	}

	@Test
	public void TestCase3() {

		Caseys_HomePage chp = new Caseys_HomePage(driver);
		Caseys_Login login = new Caseys_Login(driver);

		chp.Signinbuttonclick().click();
		login.usernametextbox().sendKeys(prop.getProperty("id"));
		login.passwordtextbox().sendKeys(prop.getProperty("password"));
		cl.signinbuttonclick().click();
		String finaltext = chp.finalmsgcheck().getText();
		String expectedtext = "Hi, Tharun!";
		Assert.assertEquals(finaltext, expectedtext);

	}

	@AfterMethod
	public void driverclose() {
		driver.close();
	}

	@AfterMethod
	public void takesScreenshot() throws IOException {
		
		takesnapshot(driver, prop.getProperty("caseysScreenShot"));
	}

}
