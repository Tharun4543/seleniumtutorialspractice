package SeleniumTraining.TestNG;

import java.time.Duration;
import java.util.Properties;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class SpiceJet_Main extends baseclasses {

	WebDriver driver;
	Properties prop;
	
	@BeforeMethod
	public void browserlaunch() throws IOException {
		prop = getdata();
		driver = initializebrowser(prop.getProperty("spicejeturl"));
	}
	
	@Test
	public void TestCase4() throws InterruptedException, IOException {
		
		Actions action2 = new Actions(driver);
		prop = getdata();
		
		SpiceJet_HomePage jet = new SpiceJet_HomePage(driver);
		SpiceJet_SearchFlight flight = new SpiceJet_SearchFlight(driver);
		
		jet.fromairport().sendKeys(prop.getProperty("fromcity"));
		jet.toairport().click();
		jet.toairportclick().click();
		jet.depdateclick().click();
		jet.datepopupdisappear();
		jet.passengerclick().click();
		action2.moveToElement(shp.adultcntclick()).click().click().click().build().perform();
		jet.childcntclick().click();
		jet.infantcntclick().click();
		jet.passengerclick().click();
		jet.currencyclick().click();
		jet.currentchooseclick().click();
		jet.familyandfriendradio().click();
		jet.searchflightbutton().click();
		
		flight.checkbuttonclick().click();
		flight.continuebuttonclick().click();
		flight.popupdisappearwait();
		String actualText = flight.getfinaltext().getText();
		String expectedText = "Passengers :  4 Adults 1 Child  1 Infant ";
		Assert.assertEquals(actualText, expectedText);
		
	}
	
	@Test
	public void TestCase5() throws IOException, InterruptedException {
		
		Actions a2 = new Actions(driver);
		prop = getdata();
		
		SpiceJet_HomePage jet = new SpiceJet_HomePage(driver);
		SpiceJet_SearchFlight flight = new SpiceJet_SearchFlight(driver);
		
		jet.roundtripradioclick().click();
		System.out.println("test1");
		jet.fromairporttextboxclick().click();
		System.out.println("test2");
		jet.international().click();
		System.out.println("test3");
		jet.fromairportchoose().click();
		System.out.println("test4");
		jet.toairportchooseclick().click();
		jet.depdate1click().click();
		jet.depdate1wait();
		jet.waitmethod();
		action2.moveToElement(jet.caldecscroll()).click().click().click().build().perform();
		jet.returndateselectclick().click();
		jet.decdateselectwait();
		jet.passengerclick().click();
		action2.moveToElement(shp.adultcntclick()).click().build().perform();
		action2.moveToElement(shp.infantcntclick()).click().click().build().perform();
		jet.passengerclick().click();
		jet.currencyclick().click();
		jet.currencychooseclick1().click();
		jet.searchflightbutton().click();
		
		String actualText = flight.getfinaltext().getText();
		String expectedText = "Passengers :  2 Adults 2 Infants";
		Assert.assertEquals(actualText, expectedText);
	}
	
	@Test
	public void Testcase_6and7() throws IOException {
		Actions a2 = new Actions(driver);
		prop = getdata();
		
		SpiceJet_HomePage jet = new SpiceJet_HomePage(driver);
		
		if (jet.returndateboxcheck().equals(jet.returndategreycolor())) {
			System.out.println("TestCase 6 Result: The One way Button is enabled");
		}else {
			System.out.println("TestCase 6: The One way Button is disabled and the Round Trip is enabled");
		}	
		
		shp.roundtripradioclick().click();
		if (jet.returndateboxcheck().equals(jet.returndatewhitecolor())) {
			System.out.println("TestCase 7 Result: The One way Button is disabled and the Round Trip is enabled");
		}else {
			System.out.println("TestCase 7 Result: The One way Button is enabled");
		}	
	}
	
	@Test
	public void Testcase8() throws IOException, InterruptedException {
		Actions action2 = new Actions(driver);
		prop = getdata();
		
		SpiceJet_HomePage jet = new SpiceJet_HomePage(driver);
		SpiceJet_MyFlexiPlan plan = new SpiceJet_MyFlexiPlan(driver);
		SpiceJet_SmeTraveller travel = new SpiceJet_SmeTraveller(driver);
		
		action2.moveToElement(shp.movetoaddons()).build().perform();
		jet.muflexiplanclick().click();
		
		String window = driver.getWindowHandle();
		Set<String> CWindow = driver.getWindowHandles();
		for(String k:CWindow) {
			if (k.equals(window)) {
				continue;
			}
			driver.switchTo().window(k);
		}
		
		action2.moveToElement(flight.loginsignupclick()).build().perform();
		flight.smetravellerclick().click();
		
		Set <String> s = driver.getWindowHandles();
		for(String k :Cwindow) {
			if((k.equals(Cwindow)) || (k.equals(window))){
				continue;
			}
			driver.switchTo().window(k);
		}
		
		travel.loginwrapperform();
		travel.loginbuttonclick().click();
		System.out.println("Loginbutton got clicked");
		Thread.sleep(2000);
		String acterrormsg = travel.usernameerrormsgcheck().getText();
		System.out.println(acterrormsg);
		String experrormsg = "The User name field is required.";
		
		Assert.assertEquals(acterrormsg, experrormsg);
	}
	
	@AfterMethod
	public void driverclose() {
		driver.close();
		driver.quit();
	}
	
	@AfterMethod
	public void takesScreenshot() throws IOException {
		takesnapshot(driver, prop.getProperty("spicejetScreenShot"));
	}
	
}
