package SeleniumTraining.TestNG;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CaseysSTP {

	WebDriver driver;
	WebDriverWait wait;
	@FindBy (xpath="//section[@class='Section']/h2[text()='Choose Your Pizza']")
	WebElement choosepizzatext;
	@FindBy (xpath="//h3[contains(text(),'Pepperoni Pizza')]/ancestor::div[@class='col-7 p-0 text-left']/descendant::span[text()=' Add ']")
	WebElement addbutton;
	@FindBy (xpath="//h3[contains(text(),'Pepperoni Pizza')]/ancestor::div[@class='col-7 p-0 text-left']/descendant::select[@name='quantity']")
	WebElement quantityclick;
	@FindBy (xpath="//h3[contains(text(),'Pepperoni Pizza')]/ancestor::div[@class='col-7 p-0 text-left']/descendant::select[@name='quantity']/option[text()='2']")
	WebElement pizzacount;

	public CaseysSTP(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		PageFactory.initElements(driver,this);
	}
	
	public WebDriverWait choosepizzatextwait() {
		wait.until(ExpectedConditions.visibilityOf(choosepizzatext));
		return wait;
	}
	public WebElement addbuttonclick() {
		return addbutton;
	}
	public WebElement quantityclick() {
		return quantityclick;
	}
	public WebElement pizzacountclick() {
		return pizzacount;
	}
	
	
	
}
