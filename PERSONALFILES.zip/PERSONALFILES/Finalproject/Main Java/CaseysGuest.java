package SeleniumTraining.TestNG;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CaseysGuest {
	WebDriver driver;
	WebDriverWait wait;
	
	@FindBy (xpath="//a[@data-automation-id='closeCheckoutLink']")
	WebElement closecheckouttext;
	@FindBy (xpath="//a[text()='Guest Checkout']")
	WebElement guestcheckoutbutton;
	@FindBy (name="fname")
	WebElement firstname;
	@FindBy (name="lname")
	WebElement lastname;
	@FindBy (name="emailaddress")
	WebElement email;
	@FindBy (name="phone")
	WebElement phone;
	@FindBy (xpath="//button[@data-automation-id='submitButton']")
	WebElement continuebutton;
		
	public CaseysGuest(WebDriver driver) {
		this.driver=driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		PageFactory.initElements(driver,this);
	}
	
	public WebElement guestcheckoutbuttonclick() {
		wait.until(ExpectedConditions.visibilityOf(closecheckouttext));
		return guestcheckoutbutton;
	}
	public WebElement firstnametextbox() {
		return firstname;
	}
	public WebElement lastnametextbox() {
		return lastname;
	}
	public WebElement emailtextbox() {
		return email;
	}
	public WebElement phonenumbertextbox() {
		return phone;
	}
	public WebElement continuebuttonclick() {
		return continuebutton;
	}
	
}
