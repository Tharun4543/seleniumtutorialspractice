package SeleniumTraining.TestNG;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class baseclasses {

	//WebDriver driver;
	
	public WebDriver initializebrowser(String url) {
		
		//ChromeOptions noti = new ChromeOptions();
		//noti.addArguments("--disable-notifications");
	//	System.setProperty("webdriver.edge.driver", "Driver/msedgedriver.exe");
	//	WebDriver driver = new EdgeDriver();
		System.setProperty("webdriver.chrome.driver", "Driver/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get(url);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		return driver;
		
	}
	
	public Properties getdata() throws IOException {
		File file = new File("C:\\Users\\Pisanaka\\eclipse-workspace\\TestNG\\src\\main\\java\\testdata.properties");
		FileInputStream fis = new FileInputStream(file);
		Properties prop = new Properties();
		prop.load(fis);
		return prop;		
	}
	
	public String takesnapshot(WebDriver driver, String testcasename) throws IOException {
		String path = System.getProperty("user.dir")+"\\ScreenShots\\"+testcasename+".png";
		TakesScreenshot scrshot = ((TakesScreenshot)driver);
		File srcfile = scrshot.getScreenshotAs(OutputType.FILE);
		File destfile = new File(path);
		FileUtils.copyFile(srcfile , destfile);
		return path;
		
	}
	
	public ExtentReports reportconfig() {
		String path = System.getProperty("user.dir")+"\\Report\\Sample_Reports.html";
		ExtentSparkReporter rep = new ExtentSparkReporter(path);
		rep.config().setDocumentTitle("Report for Training TestCases");
		rep.config().setReportName("Execution Results");
		
		ExtentReports extent = new ExtentReports();
		extent.attachReporter(rep);
		extent.setSystemInfo("Prasanna", "Tester");
		return extent;
	}
}
