package SeleniumTraining.TestNG;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SpiceJetSearch {

	WebDriver driver;
	WebDriverWait wait;
	
	public SpiceJetSearch(WebDriver driver) {
		this.driver=driver;
		wait = new WebDriverWait(driver,Duration.ofSeconds(20));
		PageFactory.initElements(driver,this);
	}

	@FindBy(xpath="//div[@class='css-1dbjc4n r-1awozwy r-1loqt21 r-18u37iz r-1otgn73']/div[@class='css-1dbjc4n r-zso239']")
	WebElement checkbutton1;
	@FindBy(xpath="//div[@class='css-1dbjc4n r-1awozwy r-z2wwpe r-1loqt21 r-18u37iz r-1777fci r-d9fdf6 r-1w50u8q r-ah5dr5 r-1otgn73']")
	WebElement continuebutton;
	@FindBy(xpath="//div[contains(@style,' display: none;')]")
	WebElement popupdisappear;
	@FindBy(xpath="//span[@class='css-76zvg2 css-16my406 r-homxoj r-7o8qx1 r-1s6pnzw r-ge9izo']")
	WebElement finalchecktext;
	
	public WebElement checkbuttonclick() {
		return checkbutton1;
	}
	public WebElement continuebuttonclick() {
		return continuebutton;
	}
	public WebElement getfinaltext() {
		return finalchecktext;
	}
	public WebDriverWait popupdisappearwait() {
		wait.until(ExpectedConditions.invisibilityOf(popupdisappear));
		return wait;
	}
	
	
}
