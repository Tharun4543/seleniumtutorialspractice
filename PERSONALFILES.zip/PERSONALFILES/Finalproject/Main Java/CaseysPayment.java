package SeleniumTraining.TestNG;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CaseysPayment {
	
	WebDriver driver;
	WebDriverWait wait;
	@FindBy (xpath="//div[@class='w-100']/div[text()='Pepperoni Pizza']")
	WebElement finalpizzachecktext;
	@FindBy (xpath="//div[@class='CartProductInfo__quantity pr-25 font-weight-bold']")
	WebElement finalpizzacounttext;
	
	public CaseysPayment(WebDriver driver) {
		this.driver=driver;
		wait  = new WebDriverWait(driver, Duration.ofSeconds(40));
		PageFactory.initElements(driver,this);
	}
	
	public WebElement finalpizzatext() {
		return finalpizzachecktext;
	}
	
	public WebElement finalpizzacntext() {
		return finalpizzacounttext;
	}
	
	
}
