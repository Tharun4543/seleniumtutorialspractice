package SeleniumTraining.TestNG;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CaseysAddress {

	WebDriver driver;
	WebDriverWait wait;
	
//	@FindBy (xpath="//div[contains(@class,'StoreSelection__store-results_header')]/div[text()='Showing 15 of 15 store']")
	@FindBy (xpath="//div[contains(text(),'47438')]")
	WebElement addresspagewait;
	@FindBy (xpath="//div[contains(text(),'47438')]/ancestor::div[@class='StoreCardBody mb-1 ']/following-sibling::div[2]/form/button")
	WebElement startorderbutton;
	@FindBy (xpath="//div[@class='d-flex align-items-center']/div[@class='StoreCardError__message']")
	WebElement errortext;
	@FindBy (name="time_select")
	WebElement timeclickbutton;
	@FindBy (xpath="//option[@value='06:00 PM']")
	WebElement timeselect;
	@FindBy (xpath="//div[@class='StoreCardRow p-2']/form/button[@data-automation-id='startOrderButton']")
	WebElement delstartorder;
	
	public CaseysAddress (WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		PageFactory.initElements(driver,this);
	}
	public WebElement startorderclick() {
		wait.until(ExpectedConditions.visibilityOf(addresspagewait));
		return startorderbutton;
	}
	public WebElement timebuttonclick() {
		wait.until(ExpectedConditions.visibilityOf(errortext));
		return timeclickbutton;
	}
	public WebElement timeselectoption() {
		return timeselect;
	}
	public WebElement delstartorderbuttonclick() {
		return delstartorder;
	}
	
}
