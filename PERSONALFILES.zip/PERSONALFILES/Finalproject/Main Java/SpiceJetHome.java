package SeleniumTraining.TestNG;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SpiceJetHome {
	
	WebDriver driver;
	WebDriverWait wait;
	
	public SpiceJet_HomePage(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver,Duration.ofSeconds(20));
		PageFactory.initElements(driver,this);
	}
	@FindBy (xpath="//div[@data-testid='round-trip-radio-button']/div/*[local-name()='svg']/*[local-name()='circle']")
	WebElement roundtripradio;
	
	@FindBy(xpath="//div[text()='From']/following-sibling::div/input")
	WebElement fromtextbox;
	@FindBy(xpath="//div[text()='To']/following-sibling::div/input")
	WebElement totextboxclick;
	@FindBy(xpath="//div[text()='KQH']")
	WebElement totext;

	@FindBy (xpath="//div[text()='From']")
	WebElement fromtextboxtestcase5;
	@FindBy (xpath="//div[text()='International']")
	WebElement internationalclick;
	@FindBy (xpath="//div[text()='BKK']")
	WebElement fromairportchoose;
	@FindBy (xpath="//div[text()='IXC']")
	WebElement toairportchoose;
	
	@FindBy(xpath="//div[@data-testid='undefined-month-August-2022']/descendant::div[text()='13']")
	WebElement depdate1;
	@FindBy (xpath="//div[text()='Sat, 13 Aug 2022']")
	WebElement depdate1wait;
	@FindBy(xpath="//div[@data-testid='undefined-month-August-2022']/descendant::div[text()='1']")
	WebElement depdate;
	@FindBy(xpath="//div[text()='Mon, 1 Aug 2022']")
	WebElement depdatepopup;
	
	@FindBy (xpath="//div[@class='css-1dbjc4n r-18u37iz']/following-sibling::div[@class='css-1dbjc4n r-1niwhzg r-z2wwpe r-17b9qp5 r-1g94qm0 r-h3f8nf r-u8s1d r-u3yave r-8fdsdq']")
	WebElement waitelement1;

	@FindBy (xpath="//div[text()='Return Date']")
	WebElement returndate;
	@FindBy (xpath="//div[@data-testid='undefined-calendar-picker']/div[contains(@class,'r-u8s1d r-11xbo3g')]")
	WebElement movetodec;
	@FindBy (xpath="//div[@data-testid='undefined-month-December-2022']/descendant::div[text()='30']")
	WebElement returndateselect;
	@FindBy (xpath="//div[text()='Fri, 30 Dec 2022']")
	WebElement decdateselectwait;
	
	@FindBy(xpath="//div[text()='Passengers']")
	WebElement passengertext;
	@FindBy(xpath="//div[contains(@data-testid,'Adult-testID-plus-one-cta')]")
	WebElement adultcnt;
	@FindBy(xpath="//div[contains(@data-testid,'Children-testID-plus-one-cta')]")
	WebElement childcnt;
	@FindBy(xpath="//div[contains(@data-testid,'Infant-testID-plus-one-cta')]")
	WebElement infantcnt;
	
	@FindBy(xpath="//div[text()='Currency']")
	WebElement currencyclick;
	@FindBy(xpath="//div[text()='AED']")
	WebElement currencychoose;
	@FindBy(xpath="//div[text()='THB']")
	WebElement currencychoose1;
	
	@FindBy(xpath="//div[text()='Family & Friends']/parent::div/preceding-sibling::div")
	WebElement radiobutton1;
	@FindBy(xpath="//div[@data-testid='home-page-flight-cta']")
	WebElement bookflightbutton;
	
	public WebElement fromairporttextboxclick() {
		return fromtextboxtestcase5;
	}
	public WebElement toairportchooseclick() {
		return toairportchoose;
	}
	public WebElement roundtripradioclick() {
		return roundtripradio;
	}
	public WebElement fromairport() {
		return fromtextbox;
	}
	public WebElement international() {
		return internationalclick;
	}
	public WebElement fromairportchoose() {
		return fromairportchoose;
	}
	public WebElement toairport() {
		return totextboxclick;
	}
	public WebElement toairportclick() {
		return totext;
	}
	public WebElement depdate1click() {
		return depdate1;
	}
	public WebDriverWait depdate1wait() {
		wait.until(ExpectedConditions.visibilityOf(depdate1wait));
		return wait;
	}
	public WebDriverWait waitmethod() {
		wait.until(ExpectedConditions.visibilityOf(waitelement1));
		return wait;
	}
	public WebElement caldecscroll() {
		return movetodec;
	}
	
	public WebElement depdateclick() {
		return depdate;
	}
	public WebElement returndateclick() {
		return returndate;
	}
	public WebElement returndateselectclick() {
		return returndateselect;
	}
	public WebDriverWait decdateselectwait() {
		wait.until(ExpectedConditions.visibilityOf(decdateselectwait));
		return wait;
	}
	public WebElement passengerclick() {
		return passengertext;
	}
	
	public WebElement adultcntclick() {
		return adultcnt;
	}
	public WebElement childcntclick() {
		return childcnt;
	}
	public WebElement infantcntclick() {
		return infantcnt;
	}
	public WebElement currencyclick() {
		return currencyclick;
	}
	public WebElement currentchooseclick() {
		return currencychoose;
	}
	public WebElement currencychooseclick1() {
		return currencychoose1;
	}
	public WebElement familyandfriendradio() {
		return radiobutton1;
	}
	
	public WebElement searchflightbutton() {
		return bookflightbutton;
	}
	public WebDriverWait datepopupdisappear() {
		wait.until(ExpectedConditions.visibilityOf(depdatepopup));
		return wait;
	}
	
	@FindBy(xpath="//div[@class='css-76zvg2 css-bfa6kz r-1862ga2 r-1gkfh8e'][contains(text(),'Return Date')]")
	WebElement returndatebox;
	@FindBy(xpath="//div[@class='css-76zvg2 css-bfa6kz r-1862ga2 r-1gkfh8e'][contains(@style,'opacity: 0.5')]")
	WebElement returndategrey;
	@FindBy(xpath="//div[@class='css-76zvg2 css-bfa6kz r-1862ga2 r-1gkfh8e'][contains(@style,'opacity: 1')][text()='Return Date']")
	WebElement returndatewhite;
	
	public WebElement returndateboxcheck() {
		return returndatebox;
	}
	public WebElement returndategreycolor() {
		return returndategrey;
	}
	public WebElement returndatewhitecolor() {
		return returndatewhite;
	}
	
	@FindBy(xpath="//div[text()='Add-ons']")
	WebElement addons;
	@FindBy(xpath="//div[text()='MyFlexiPlan']")
	WebElement myflexiplan;
	
	public WebElement movetoaddons() {
		return addons;
	}
	public WebElement muflexiplanclick() {
		return myflexiplan;
	}
	
	
	
}
	
	
	