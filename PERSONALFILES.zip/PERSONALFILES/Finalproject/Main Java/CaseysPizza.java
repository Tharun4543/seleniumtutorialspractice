package SeleniumTraining.TestNG;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CaseysPizza {

	WebDriver driver;
	WebDriverWait wait;
	
	@FindBy (xpath="//section[@class='Section']/h1[text()='Pizza']")
	WebElement pizzatextwait;
	@FindBy (xpath="//a[contains(@href,'single-topping-pizza')]")
	WebElement pizzabutton;
	
	public CaseysPizza(WebDriver driver) {
		this.driver=driver;
		wait  = new WebDriverWait(driver, Duration.ofSeconds(40));
		PageFactory.initElements(driver,this);
	}
	public WebElement pizzabuttonclick() {
		wait.until(ExpectedConditions.visibilityOf(pizzatextwait));
		return pizzabutton;
	}
	
}
