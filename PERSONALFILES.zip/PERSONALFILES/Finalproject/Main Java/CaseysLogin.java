package SeleniumTraining.TestNG;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CaseysLogin {
	
	WebDriver driver;
	WebDriverWait wait;
	
	private By signintext = By.xpath("//div[@id='screensetcontainer_content']/descendant::h2[text()='Sign in']");
	private By usernametextbox = By.xpath("//div[@id='screensetcontainer_content']/descendant::input[@name='username']");
	private By passwordtextbox = By.xpath("//div[@id='screensetcontainer_content']/descendant::input[@name='password']");
	private By signinbutton = By.xpath("//div[@id='screensetcontainer_content']/descendant::input[@type='submit']");
	
	public CaseysLogin(WebDriver driver) {
		this.driver=driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		PageFactory.initElements(driver,this);
	}
	
	public WebElement usernametextbox() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(signintext));
		return driver.findElement(usernametextbox);
	}
	public WebElement passwordtextbox() {
		return driver.findElement(passwordtextbox);
	}
	public WebElement signinbuttonclick() {
		return driver.findElement(signinbutton);
	}
	
}
