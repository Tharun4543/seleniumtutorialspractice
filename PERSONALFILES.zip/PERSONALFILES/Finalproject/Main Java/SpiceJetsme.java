package SeleniumTraining.TestNG;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SpiceJetsme {
	
	WebDriver driver;
	WebDriverWait wait;
	
	public SpiceJetsme(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver,Duration.ofSeconds(20));
		PageFactory.initElements(driver,this);
	}
	
	@FindBy(xpath="//div[@class='loginFormWrapper']")
	WebElement loginform;
	@FindBy(id="UserName")
	WebElement idtext;
	@FindBy(id="LoginPassword")
	WebElement pswdtext;
	@FindBy(xpath="//button[@class='loginButton btn btn-danger']")
	WebElement loginbutton;
	@FindBy(xpath="//span[@data-valmsg-for='UserName']")
	WebElement usernametexterror;
	
	public WebDriverWait loginwrapperform() {
		wait.until(ExpectedConditions.visibilityOf(loginform));
		return wait;
	}
	public WebElement loginbuttonclick() {
		return loginbutton;
	}
	public WebElement usernameerrormsgcheck() {
		return usernametexterror;
	}
	
	
}
