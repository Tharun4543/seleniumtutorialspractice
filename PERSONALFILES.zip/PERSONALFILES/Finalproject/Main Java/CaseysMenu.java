package SeleniumTraining.TestNG;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CaseysMenu {
	
	WebDriver driver;
	WebDriverWait wait;
	
	@FindBy (xpath="//section[@class='Section']/h1[text()='Menu']")
	WebElement menuvisible;
	@FindBy (xpath="//a/h2[text()='Pizza']/ancestor::div[contains(@class,'px-2 px-lg-0 mb-4 last-row-center-item')]")
	WebElement pizzaclick;

	public CaseysMenu (WebDriver driver) {
		this.driver=driver;
		wait  = new WebDriverWait(driver, Duration.ofSeconds(40));
		PageFactory.initElements(driver,this);
	}
	public WebDriverWait menutextvisible() {
		wait.until(ExpectedConditions.visibilityOf(menuvisible));
		return wait;
	}
	
	public WebElement pizzaclick() {
		return pizzaclick;
	}
	
	
}
