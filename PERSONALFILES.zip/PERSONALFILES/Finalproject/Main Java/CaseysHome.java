package SeleniumTraining.TestNG;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CaseysHome {
	WebDriver driver;
	WebDriverWait wait;
	
	@FindBy (xpath="//iframe[@name ='ViralSweep Promotion Embed']")
	WebElement framename;
	@FindBy (className="lightbox_close_toggle")
	WebElement frameclose;
	@FindBy (xpath="//button[@data-automation-id='carryout']")
	WebElement pickbutton;
	@FindBy (xpath="//input[@data-automation-id='addressSearchField']")
	WebElement pickaddresstextbox;
	@FindBy (xpath="//button[@data-automation-id='delivery']")
	WebElement deliverybutton;
	@FindBy (xpath="//div[@class='NavSignedInMenu NavSignedInMenu--signed-in theme-dark']/a")
	WebElement signinbutton;
	@FindBy (xpath="//div[@class='NavSignedInMenu NavSignedInMenu--signed-in theme-dark']/a[contains(text(),'Hi')]")
	WebElement userloginmsgtext;	
		
	public CaseysHome (WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(50));
		PageFactory.initElements(driver,this);
	}
	
	public WebElement frameclose() throws InterruptedException {
		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(framename));
		Thread.sleep(5000);
		return frameclose;
	}
	public WebElement pickupbutton() {
		wait.until(ExpectedConditions.elementToBeClickable(pickbutton));
		return pickbutton;
	}
	public WebElement pickuptextbox() {
		 return pickaddresstextbox;
	}
	public WebElement deliverybuttonclick() {
		wait.until(ExpectedConditions.elementToBeClickable(deliverybutton));
		return deliverybutton;
	}
	public WebElement Signinbuttonclick() {
		return signinbutton;
	}
	public WebElement finalmsgcheck() {
		wait.until(ExpectedConditions.visibilityOf(userloginmsgtext));
		return userloginmsgtext;
	}
	
	
}
