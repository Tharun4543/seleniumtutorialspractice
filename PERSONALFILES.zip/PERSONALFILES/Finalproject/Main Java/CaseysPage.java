package SeleniumTraining.TestNG;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Caseyspage {

	WebDriver driver;
	WebDriverWait wait;
	@FindBy (xpath="\"//div[@class='col-8 col-sm-9']/h1[text()='Your Order']")
	WebElement yourordertext;
	@FindBy (xpath="//div[@class='CartFooter__desktop d-none d-md-block visible']")
	WebElement footerinvisible;
	@FindBy (xpath="//div[@class='CartFooter__static']/descendant::a[@data-automation-id='checkoutButton']")
	WebElement checkoutbutton;
	
	public Caseyspage(WebDriver driver) {
		this.driver=driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(40));
		PageFactory.initElements(driver,this);
	}
	
	public WebDriverWait yourordertextwait() {
		wait.until(ExpectedConditions.visibilityOf(yourordertext));
		return wait;
	}
	public WebElement checkoutbuttonclick() {
		wait.until(ExpectedConditions.invisibilityOf(footerinvisible));
		return checkoutbutton;
	}
	
}
